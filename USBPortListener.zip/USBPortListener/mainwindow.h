#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOMessage.h>
#include <IOKit/IOCFPlugIn.h>
#include <IOKit/usb/IOUSBLib.h>
#include <IOKit/serial/IOSerialKeys.h>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow {
    Q_OBJECT

   public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

   private:
    Ui::MainWindow       *ui;
    IONotificationPortRef notificationPort;

   private:
    static void deviceAdded(void *refCon, io_iterator_t iterator);
    static void deviceRemoved(void *refCon, io_service_t service, natural_t messageType, void *messageArgument);
};
#endif  // MAINWINDOW_H
