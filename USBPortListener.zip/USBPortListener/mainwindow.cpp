#include <iostream>
#include "mainwindow.h"
#include "./ui_mainwindow.h"

typedef struct USBDevicePrivateData {
    io_object_t notification;
    QString     deviceName;
    MainWindow *window;
} USBDevicePrivateData;

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    // 设置窗口置顶
    this->setWindowFlags(Qt::Window | Qt::WindowStaysOnTopHint);
    // 窗口透明度
    this->setWindowOpacity(0.8);
    // portList 高度自适应, 上下滚动
    ui->portList->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);

    // 注册设备添加通知
    CFMutableDictionaryRef matchingDict = IOServiceMatching(kIOSerialBSDServiceValue);
    CFDictionarySetValue(matchingDict, CFSTR(kIOSerialBSDTypeKey), CFSTR(kIOSerialBSDAllTypes));

    notificationPort                 = IONotificationPortCreate(kIOMainPortDefault);
    CFRunLoopSourceRef runLoopSource = IONotificationPortGetRunLoopSource(notificationPort);
    CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, kCFRunLoopDefaultMode);

    io_iterator_t addIterator;
    IOServiceAddMatchingNotification(notificationPort, kIOMatchedNotification, matchingDict, deviceAdded, this,
                                     &addIterator);

    // 遍历已经连接的设备
    deviceAdded(this, addIterator);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::deviceAdded(void *refCon, io_iterator_t iterator) {
    MainWindow   *thisWindow = (MainWindow *)refCon;
    kern_return_t kr;
    io_object_t   newDevice;

    while ((newDevice = IOIteratorNext(iterator))) {
        USBDevicePrivateData *privateDataRef = NULL;
        privateDataRef                       = (USBDevicePrivateData *)malloc(sizeof(USBDevicePrivateData));
        bzero(privateDataRef, sizeof(USBDevicePrivateData));
        privateDataRef->window = thisWindow;

        // 获取设备BSD名称
        CFStringRef bsdPathAsCFString =
            (CFStringRef)IORegistryEntryCreateCFProperty(newDevice, CFSTR(kIOCalloutDeviceKey), kCFAllocatorDefault, 0);
        if (bsdPathAsCFString) {
            // 过滤带"Bluetooth"字段的设备
            if (CFStringFind(bsdPathAsCFString, CFSTR("Bluetooth"), kCFCompareCaseInsensitive).location != kCFNotFound) {
                CFRelease(bsdPathAsCFString);
                continue;
            }
            // 过滤带"HUAWEI"字段的设备
            if (CFStringFind(bsdPathAsCFString, CFSTR("HUAWEI"), kCFCompareCaseInsensitive).location != kCFNotFound) {
                CFRelease(bsdPathAsCFString);
                continue;
            }

            char deviceName[256];
            if (CFStringGetCString(bsdPathAsCFString, deviceName, sizeof(deviceName), kCFStringEncodingUTF8)) {
                std::cout << "Device added: " <<deviceName << std::endl;
                privateDataRef->deviceName = QString::fromUtf8(deviceName);
                QString portList           = thisWindow->ui->portList->text();
                // 添加新的设备
                thisWindow->ui->portList->setText(portList + QString::fromCFString(bsdPathAsCFString) + "\r\n");
            }
            CFRelease(bsdPathAsCFString);
        }

        // 注册设备移除通知
        kr = IOServiceAddInterestNotification(thisWindow->notificationPort,    // notifyPort
                                              newDevice,                       // service
                                              kIOGeneralInterest,              // interestType
                                              deviceRemoved,                   // callback
                                              privateDataRef,                  // refCon
                                              &(privateDataRef->notification)  //
        );

        if (KERN_SUCCESS != kr) {
            std::cout << "IOServiceAddInterestNotification failed" << std::endl;
        }
    }
}

void MainWindow::deviceRemoved(void *refCon, io_service_t service, natural_t messageType, void *messageArgument) {
    kern_return_t         kr;
    USBDevicePrivateData *privateDataRef = (USBDevicePrivateData *)refCon;

    if (messageType == kIOMessageServiceIsTerminated) {
        std::cout << "Device removed: " << privateDataRef->deviceName.toStdString() << std::endl;
        // 更新UI
        QString portList = privateDataRef->window->ui->portList->text();
        portList.replace(privateDataRef->deviceName + "\r\n", "");
        privateDataRef->window->ui->portList->setText(portList);

        IOObjectRelease(privateDataRef->notification);
        free(privateDataRef);
    }
}
